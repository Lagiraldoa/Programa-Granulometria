/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.granulometria;

import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author leon
 */
public class Principal {
   
    public static void main(String[] args) {
        
       System.out.println("********************Bienvenido a su programa para calcular granulometrías********************");
        
       System.out.println("1 Cálculo de la granulometría de la Arena");
       System.out.println("2 Cálculo de la granulometría para la grava de 3/8");
       
       Scanner teclado = new Scanner(System.in);
        System.out.println("\n" + "Por favor seleccione una opción: ");
        int opcion = teclado.nextInt();
        
        
       switch (opcion) {
            case 1:
       
      
        Scanner sc = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso Seco: ");
        double peso1 = sc.nextDouble(); 
        
        Scanner sc1 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°4: ");
        double ret4 = sc1.nextDouble(); 
        
        Scanner sc2 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°8: ");
        double ret8 = sc2.nextDouble(); 
        
        Scanner sc3 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°16: ");
        double ret16 = sc3.nextDouble(); 
        
        Scanner sc4 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°30: ");
        double ret30 = sc4.nextDouble(); 
        
        Scanner sc5 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°50: ");
        double ret50 = sc5.nextDouble(); 
        
        Scanner sc6 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°100: ");
        double ret100 = sc6.nextDouble(); 
        
        Scanner sc7 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°200: ");
        double ret200 = sc7.nextDouble(); 
        
        
       ArrayList<Double> pesos = new ArrayList();
       pesos.add(ret4);
       pesos.add(ret8);
       pesos.add(ret16);
       pesos.add(ret30);
       pesos.add(ret50);
       pesos.add(ret100);
       pesos.add(ret200);
       
       Arena a1 = new Arena(peso1, pesos);
       a1.pasar(pesos);
        System.out.println("La suma de los pesos es: " + a1.pasar(pesos));
       
        double matPasa200 = a1.getPesoSeco()-a1.pasar(pesos);
        
        
        
        System.out.println("El Material que pasa la malla N°200 es: " + matPasa200);
        
        pesos.add(matPasa200);
        
       a1.porcentajeRetenido(pesos);
        System.out.println("Los porcentajes retenidos son: "+ a1.porcentajeRetenido(pesos));
        
        a1.porcentajeQuePasa(a1.porcentajeRetenido(pesos));
        System.out.println("Los porcentajes que pasan cada malla son: " + a1.porcentajeQuePasa(a1.porcentajeRetenido(pesos)));
        
        break;
        
            case 2:
                
        Scanner sc8 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso Seco: ");
        double peso1_ = sc8.nextDouble(); 
        
        Scanner sc9 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°3/8: ");
        double ret3_8 = sc9.nextDouble(); 
        
        Scanner sc10 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°4: ");
        double ret4_ = sc10.nextDouble(); 
        
        Scanner sc11 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°8: ");
        double ret8_ = sc11.nextDouble(); 
        
        Scanner sc12 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°16: ");
        double ret16_ = sc12.nextDouble(); 
        
        Scanner sc13 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°30: ");
        double ret30_ = sc13.nextDouble(); 
        
        Scanner sc14 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°50: ");
        double ret50_ = sc14.nextDouble(); 
        
        Scanner sc15 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°100: ");
        double ret100_ = sc15.nextDouble(); 
                
        Scanner sc16 = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso retenido en la malla N°200: ");
        double ret200_ = sc16.nextDouble(); 
        
       ArrayList<Double> pesos_ = new ArrayList();
       pesos_.add(ret3_8);
       pesos_.add(ret4_);
       pesos_.add(ret8_);
       pesos_.add(ret16_);
       pesos_.add(ret30_);
       pesos_.add(ret50_);
       pesos_.add(ret100_);
       pesos_.add(ret200_);
       
       TresOct a2 = new TresOct(peso1_, pesos_);
       a2.pasar(pesos_);
        System.out.println("La suma de los pesos es: " + a2.pasar(pesos_));
       
        double matPasa_200 = a2.getPesoSeco()-a2.pasar(pesos_);
        
        
        
        System.out.println("El Material que pasa la malla N°200 es: " + matPasa_200);
        
        pesos_.add(matPasa_200);
        
       a2.porcentajeRetenido(pesos_);
        System.out.println("Los porcentajes retenidos son: "+ a2.porcentajeRetenido(pesos_));
        
        a2.porcentajeQuePasa(a2.porcentajeRetenido(pesos_));
        System.out.println("Los porcentajes que pasan cada malla son: " + a2.porcentajeQuePasa(a2.porcentajeRetenido(pesos_)));
        
                       
        break;        
       }
    }

}