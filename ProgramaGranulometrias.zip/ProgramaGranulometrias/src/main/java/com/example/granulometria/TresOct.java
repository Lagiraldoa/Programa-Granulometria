/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.granulometria;

import java.util.ArrayList;

/**
 *
 * @author leon
 */
class TresOct extends GranulometriaFinos implements Calculo {

    public TresOct(double pesoSeco, ArrayList<Double> pesos) {
        super(pesoSeco, pesos);
    }
    
    

    @Override
    public double pasar(ArrayList<Double> pesos) {
        double suma= 0;
        
    for(int i = 0; i < pesos.size(); i++){
    
    suma = suma + pesos.get(i);
    
    
    }
        return suma;
    }

    @Override
    public ArrayList<Double> porcentajeRetenido(ArrayList<Double> pesos) {
        ArrayList<Double>retenidos = new ArrayList();
        for(int i = 0; i < pesos.size(); i++){
        retenidos.add((100/pesoSeco)*pesos.get(i));
        }
        return retenidos;
        
    }

    @Override
    public ArrayList<Double> porcentajeQuePasa(ArrayList<Double> retenidos) {
      ArrayList<Double> porcPasa = new ArrayList();
        double acumulador = 100;
        for(int i = 0; i < retenidos.size(); i++){
    
        
        
        acumulador -= (retenidos.get(i));
        
        porcPasa.add(acumulador);
        }
        return porcPasa;
          
    }
    
}
