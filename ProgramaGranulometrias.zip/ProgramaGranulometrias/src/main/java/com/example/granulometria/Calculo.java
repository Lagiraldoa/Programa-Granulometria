/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.example.granulometria;

import java.util.ArrayList;

/**
 *
 * @author leon
 */
public interface Calculo {
    
public abstract double pasar(ArrayList<Double>pesos);   


public abstract ArrayList<Double> porcentajeRetenido(ArrayList<Double>pesos);


public abstract ArrayList<Double> porcentajeQuePasa(ArrayList<Double>retenidos);

}