
package com.example.granulometria;

import java.util.ArrayList;




public abstract class GranulometriaFinos {
    
    double pesoSeco;
    private ArrayList<Double>pesos;

    public GranulometriaFinos(double pesoSeco, ArrayList<Double> pesos) {
        this.pesoSeco = pesoSeco;
        this.pesos = pesos;
    }

    public double getPesoSeco() {
        return pesoSeco;
    }

    public void setPesoSeco(double pesoSeco) {
        this.pesoSeco = pesoSeco;
    }

    public ArrayList<Double> getPesos() {
        return pesos;
    }

    public void setPesos(ArrayList<Double> pesos) {
        this.pesos = pesos;
    }

   
    

    
    
    

    
}
